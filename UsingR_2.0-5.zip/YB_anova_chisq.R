library(readxl)
library(dplyr)
library(agricolae)


avo_file <- "YB2XL_ANOVA-4 SHEETS.xlsx"
chi_file <- "YB2XL_CHI SQUARE-16 SHEETS.xlsx"


avo_sht_names <- excel_sheets(avo_file)
chi_sht_names <- excel_sheets(chi_file)

avo_data <- lapply(avo_sht_names, function(x) read_xlsx(avo_file, sheet = x))
chi_data <- lapply(chi_sht_names, function(x) read_xlsx(chi_file, sheet = x))

fn <- sub(".xlsx", "_result2.txt", avo_file)
sink(fn, append = T)
for(i in 1:length(avo_data)) {
  df <- avo_data[[i]]
  colnames(df) <- c("Genotype", "Germination_Rate")
  fit <- aov(Germination_Rate ~ Genotype, data = df)
  cat(sprintf("### result of sheet %d ########################################\n", i))
  cat("=== ANOVA Test ===================\n")
  summary(fit) %>% print
  cat("\n")
  
  cat("=== Tukey Group =================\n")
  t <- HSD.test(fit, trt = "Genotype", unbalanced = T)
  print(t)

  cat("=== pairwise t-test ============\n")
  pairwise.t.test(df[[2]], df[[1]]) %>% print
  cat(" ################################################################\n\n\n")
}
  
sink()


#### chisq test ##############################
fnchi <- sub(".xlsx", "_result.txt", chi_file)
sink(fnchi, append = F)
for (i in 1:length(chi_data)) {
  cat(sprintf("### result of sheet %d ########################################\n", i))
  df <- chi_data[[i]]
  colnames(df)[1] <- "Genotype"
  mat <- df[, 2:ncol(df)] %>% as.matrix
  for(r in 2:nrow(mat)) {
    x <- mat[c(1, r), ]
    res <- chisq.test(x, y)
    
    cat(sprintf("%s.vs.%s:\tX-squared:%.2f;\tdf = %d;\tp-value = %s\n", 
                df[[1]][1], df[[1]][r], res$statistic, res$parameter, formatC(res$p.value, format = "e", digits = 2)))

  }
  
  cat("\n\n")
}

sink()